<header class="hero container-fluid">
    <div class="hero__content container mx-auto">
        <!-- I'm putting the nav inside this "fixed-nav-container" to fix some issues happens on scroll -->
        @includeIf('cms::frontend.layouts.navbar')
    </div>
</header>