<?php

return [
    'name' => 'Crm',
    'module_version' => '2.1',
    'pid' => 7,
];
