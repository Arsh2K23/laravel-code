<?php
return [
	'productcatalogue_module' => 'Product Catalogue Module',
	'catalogue_qr' => 'Catalogue QR',
	'generate_qr' => 'Generate QR',
	'select_business_location' => 'Select Business Location',
	'download_image' => 'Download Image',
	'qr_code_color' => 'Qr code color',
	'catalogue_instruction_1' => 'Select business location and QR code color',
	'catalogue_instruction_2' => 'Choose title, subtitle and to show logo or not',
	'catalogue_instruction_3' => 'Click on generate QR code',
	'product_catalogue' => 'Product Catalogue',
	'show_business_logo_on_qrcode' => 'Show business logo on qrcode',
	'title' => 'Title',
	'subtitle' => 'Subtitle',
	'price' => 'Price',
	'priceMenu' => 'Precio',
];