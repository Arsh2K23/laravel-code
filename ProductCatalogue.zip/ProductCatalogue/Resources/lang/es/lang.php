<?php
return [
	'productcatalogue_module' => 'Modulo catálogo de productos',
	'catalogue_qr' => 'Catálogo QR',
	'generate_qr' => 'Generate QR',
	'select_business_location' => 'Seleccione una localización',
	'download_image' => 'Descargar imágen',
	'qr_code_color' => 'Qr Color',
	'catalogue_instruction_1' => 'Seleccione un localización y un color para el código QR',
	'catalogue_instruction_2' => 'Seleccione un título, subtitulo y escoja si se muestra o no el logo en el código QR',
	'catalogue_instruction_3' => 'Click para generar el código QR',
	'product_catalogue' => 'Catalogo de Productos',
	'show_business_logo_on_qrcode' => 'Mostrar logo en el código QR',
	'title' => 'Titulo',
	'subtitle' => 'Subtitulo',
	'price' => 'Precio',
	'priceMenu' => 'Precio111',
];