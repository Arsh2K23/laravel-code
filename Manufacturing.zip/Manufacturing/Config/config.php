<?php

return [
    'name' => 'Manufacturing',
    'module_version' => '3.0',
    'pid' => 4,
];
