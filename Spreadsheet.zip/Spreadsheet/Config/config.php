<?php

return [
    'name' => 'Spreadsheet',
    'module_version' => "0.5",
    'pid' => 13
];
