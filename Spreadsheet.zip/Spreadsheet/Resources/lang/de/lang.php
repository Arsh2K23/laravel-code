<?php
return [
    'spreadsheet' => 'Kalkulationstabelle',
    'spreadsheet_module' => 'Tabellenkalkulationsmodul',
    'sheets' => 'Blätter',
    'my_spreadsheets' => 'Meine Tabellen',
    'create_spreadsheet' => 'Tabellenkalkulation erstellen',
    'no_spreadsheet_found' => 'Keine Tabelle gefunden!',
    'view_spreadsheet' => 'Tabelle anzeigen',
    'share' => 'Teilen',
    'share_excel' => 'Tabelle teilen',
    'todos' => 'Tods',
    'access_spreadsheet' => 'Tabellenkalkulation aufrufen',
    'create_spreadsheet' => 'Tabellenkalkulation erstellen',
    'spreadsheet_shared_notif_text' => ':shared_by hat eine Tabelle geteilt - :name',
    'shared_by' => 'Geteilt von : :name',
    'created_by' => 'Erstellt von: :name',
];