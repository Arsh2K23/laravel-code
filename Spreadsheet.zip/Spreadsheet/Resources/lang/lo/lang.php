<?php
return [
    'spreadsheet' => 'ຕາຕະລາງ',
    'spreadsheet_module' => 'ໂມດູນຕາຕະລາງ',
    'sheets' => 'ແຜ່ນ',
    'my_spreadsheets' => 'ຕາຕະລາງຂອງຂ້ອຍ',
    'create_spreadsheet' => 'ສ້າງສະເປຣດຊີດ',
    'no_spreadsheet_found' => 'ບໍ່ພົບສະເປຣດຊີດ!',
    'view_spreadsheet' => 'ເບິ່ງສະເປຣດຊີດ',
    'share' => 'ແບ່ງປັນ',
    'share_excel' => 'ແບ່ງປັນສະເປຣດຊີດ',
    'todos' => 'Todos',
    'access_spreadsheet' => 'ເຂົ້າເຖິງສະເປຣດຊີດ',
    'create_spreadsheet' => 'ສ້າງຕາຕະລາງ',
    'spreadsheet_shared_notif_text' => ':shared_by ແບ່ງປັນສະເປຣດຊີດ - :name',
    'shared_by' => 'ແບ່ງປັນໂດຍ : :name',
    'created_by' => 'ສ້າງໂດຍ : : name',
];