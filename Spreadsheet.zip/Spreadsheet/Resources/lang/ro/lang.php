<?php
return [
    'spreadsheet' => 'Foaie de calcul',
    'spreadsheet_module' => 'Modul tabelar',
    'sheets' => 'Foi',
    'my_spreadsheets' => 'Foile mele de calcul',
    'create_spreadsheet' => 'Creați o foaie de calcul',
    'no_spreadsheet_found' => 'Nu a fost găsită nicio foaie de calcul!',
    'view_spreadsheet' => 'Vizualizați foaia de calcul',
    'share' => 'Acțiune',
    'share_excel' => 'Partajați foaia de calcul',
    'todos' => 'Todos',
    'access_spreadsheet' => 'Accesați foaia de calcul',
    'create_spreadsheet' => 'Creați o foaie de calcul',
    'spreadsheet_shared_notif_text' => ':shared_by a distribuit o foaie de calcul - :name',
    'shared_by' => 'Distribuit de : :name',
    'created_by' => 'Creat de : :name',
];