<?php
return [
    'spreadsheet' => 'स्प्रेडशीट',
    'spreadsheet_module' => 'स्प्रेडशीट मॉड्यूल',
    'sheets' => 'शीट्स',
    'my_spreadsheets' => 'मेरी स्प्रैडशीट',
    'create_spreadsheet' => 'स्प्रेडशीट बनाएं',
    'no_spreadsheet_found' => 'कोई स्प्रेडशीट नहीं मिली!',
    'view_spreadsheet' => 'स्प्रेडशीट देखें',
    'share' => 'साझा करना',
    'share_excel' => 'स्प्रेडशीट साझा करें',
    'todos' => 'सब',
    'access_spreadsheet' => 'स्प्रैडशीट एक्सेस करें',
    'create_spreadsheet' => 'स्प्रेडशीट बनाएं',
    'spreadsheet_shared_notif_text' => ':shared_by ने एक स्प्रेडशीट साझा की - :name',
    'shared_by' => 'द्वारा साझा किया गया: :name',
    'created_by' => 'इनके द्वारा निर्मित : :name',
];