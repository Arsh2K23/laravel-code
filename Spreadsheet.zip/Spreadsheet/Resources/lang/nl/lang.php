<?php
return [
    'spreadsheet' => 'Spreadsheet',Spreadsheet
    'spreadsheet_module' => 'Spreadsheetmodule',
    'sheets' => 'Lakens',
    'my_spreadsheets' => 'Mijn spreadsheets',
    'create_spreadsheet' => 'Spreadsheet maken',
    'no_spreadsheet_found' => 'Geen spreadsheet gevonden!',
    'view_spreadsheet' => 'Spreadsheet bekijken',
    'share' => 'Deel',
    'share_excel' => 'Spreadsheet delen',
    'todos' => 'Todos',
    'access_spreadsheet' => 'Spreadsheet openen',
    'create_spreadsheet' => 'Spreadsheet maken',
    'spreadsheet_shared_notif_text' => ':shared_by heeft een spreadsheet gedeeld - :name',
    'shared_by' => 'Gedeeld door : :name',
    'created_by' => 'Gemaakt door: :name',
];