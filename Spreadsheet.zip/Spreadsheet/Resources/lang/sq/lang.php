<?php
return [
    'spreadsheet' => 'Fletëllogaritëse',
    'spreadsheet_module' => 'Moduli i fletëllogaritjes',
    'sheets' => 'Fletët',
    'my_spreadsheets' => 'Tabelat e mia',
    'create_spreadsheet' => 'Krijo Spreadsheet',
    'no_spreadsheet_found' => 'Nuk u gjet asnjë fletëllogaritëse!',
    'view_spreadsheet' => 'Shikoni fletën e llogaritjes',
    'share' => 'Shpërndaje',
    'share_excel' => 'Ndani tabelën',
    'todos' => 'Todos',
    'access_spreadsheet' => 'Qasja në fletëllogaritëse',
    'create_spreadsheet' => 'Krijo fletëllogaritëse',
    'spreadsheet_shared_notif_text' => ':shared_by ndau një fletëllogaritëse - :name',
    'shared_by' => 'Shpërndarë nga : :name',
    'created_by' => 'Krijuar nga : :name',
];