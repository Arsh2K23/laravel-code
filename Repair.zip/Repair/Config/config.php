<?php

return [
    'name' => 'Repair',
    'module_version' => '2.0',
    'pid' => 6,
    'enable_repair_check_using_mobile_num' => true,
];
